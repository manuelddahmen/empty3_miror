package one.empty.gcp.meshmask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeshmaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
